from django.core.management.base import BaseCommand
import requests
import time
import random
import re
from concurrent.futures import ThreadPoolExecutor

from players.models import Player

BASE_URL = "http://127.0.0.1:8000"
ROLE_LABEL = {"狼": "🐺狼", "狼王": "🐺狼王", "预": "🔮预言家",
              "女": "🧙女巫", "守": "🛡️守卫", "猎": "🏹猎人", "民": "🧑民"}


def run_full_game_test():
    print("🚀 开始 12 人自动建房与身份获取测试...")
    prefix = random.randint(10000, 99999)
    usernames = [f"bot_{prefix}_{i:02d}" for i in range(1, 13)]

    # 1. 创建会话并注册登录
    sessions = []
    for name in usernames:
        s = requests.Session()
        s.post(f"{BASE_URL}/accounts/register/", data={"username": name, "password": "TestPass123!"})
        s.post(f"{BASE_URL}/accounts/login/", data={"username": name, "password": "TestPass123!"})
        sessions.append(s)

    print("✅ 12 个账号注册并登录完成")

    # 2. 建房并加入
    res = sessions[0].post(f"{BASE_URL}/rooms/dining/", data={"operation": "create"})
    m = re.search(r'(\d{4})', res.text)
    if not m:
        print("❌ 建房失败，请确保服务器已启动。")
        return
    room_code = m.group(1)
    print(f"🏠 房间码：{room_code}")

    for s in sessions:
        s.post(f"{BASE_URL}/rooms/dining/", data={"operation": "join", "number": room_code})
    time.sleep(1.5)  # 等待全部加入

    # 3. 开始游戏并选择板子
    sessions[0].post(f"{BASE_URL}/process/start/{room_code}/")
    time.sleep(0.5)
    for s in sessions:
        s.post(f"{BASE_URL}/process/card/{room_code}/", data={"idtype": "狼枪守卫"})

    # 4. 全员访问一次 shuffle 页面触发发牌
    def access_shuffle(s):
        try:
            s.get(f"{BASE_URL}/process/shuffle/{room_code}/")
        except:
            pass

    with ThreadPoolExecutor(max_workers=12) as ex:
        ex.map(access_shuffle, sessions)

    # 等 1 秒让数据库落盘
    time.sleep(1.0)

    # 5. 直接从数据库查询这 12 个人的身份
    print("\n" + "=" * 50)
    print("📋 本局身份表：")

    players_db = Player.objects.filter(room__code=room_code).order_by("number")

    if not players_db.exists():
        print("❌ 没有查到玩家数据，可能发牌失败。")
        return

    for p in players_db:
        role_label = ROLE_LABEL.get(p.role, p.role) if p.role else "未分配"
        print(f"  {p.number:>2}号 {p.user.username:<20} {role_label}")

    print("=" * 50)
    print("✅ 身份获取完毕！")


class Command(BaseCommand):
    help = '获取12名玩家身份'

    def handle(self, *args, **options):
        run_full_game_test()