from django.shortcuts import render,redirect
import random
from .models import Room
from players.models import Player
from django.http import JsonResponse
from django.utils import timezone
from datetime import timedelta
from process.models import GameState
from process.views import phasedict

# Create your views here.

def dining_view(request):
    if request.method == "POST":
        value = request.POST.get("operation")   # 你按钮的 name
        # 创建房间
        if value == "create":
            roomcode = "".join(str(random.randint(0, 9)) for _ in range(4))
            Room.objects.create(code=roomcode)  # 存数据库
            return render(request, "dining.html", {"roomcode": roomcode})

        # 加入房间
        elif value == "join":
            num = request.POST.get("number")
            room = Room.objects.filter(code=num).first()
            state=GameState.objects.filter(room=room).first()
            if state and state.started == True:
                return render(request,'dining.html',{'error':'游戏已开始'})
            if room:
                numberlist=[1,2,3,4,5,6,7,8,9,10,11,12]
                players = list(Player.objects.filter(room=room).values_list('number', flat=True))
                if len(players) == 12:
                    return render(request, 'dining.html', {'error': '房间已满'})
                elif 0<len(players)<12:
                    for i in players:
                        if i in numberlist:
                            numberlist.remove(i)
                Player.objects.get_or_create(
                    room=room, user=request.user,
                    defaults={"number": numberlist[0]}
                )
                if room.players.count()==1:
                    me=Player.objects.filter(room=room,user=request.user).first()
                    me.host=True
                    me.save()
                return redirect(f"/rooms/{num}/")
            else:
                return render(request, "dining.html", {"error": "房间码不存在"})
    if request.method == 'GET':
        me = Player.objects.filter(user=request.user).first()
        if me and me.room:
            lastroom = me.room
            state = GameState.objects.filter(room=lastroom).first()

            # 安全判断：有状态、有开始标记，且没结束
            if state and (state.started or getattr(state, 'started2', False)):
                # 排除结算页面和无效阶段，防止锁死
                if state.phase != 'result':
                    return redirect(f'/process/{phasedict[state.phase]}/{lastroom.code}/')
                else:
                    # 游戏结束，清理旧记录
                    me.delete()
            else:
                # 没有开始，或者数据异常，也清理旧记录，允许开新局
                me.delete()
    return render(request, "dining.html")
def rooms_view(request,num):
    room = Room.objects.filter(code=num).first()
    if not room:
        return redirect("/rooms/dining/")

    players = room.players.all()  # 用 related_name 拿所有玩家
    me=Player.objects.filter(room=room,user=request.user).first()
    return render(request, "rooms.html", {
        "roomcode": num,
        "players": players,
        "count": len(players),
        'me':me,

    })



def leave_room(request,num):
    room = Room.objects.filter(code=num).first()
    if room:
        Player.objects.filter(room=room, user=request.user).delete()
        if  room.players.count()==0:
            room.delete()
            return redirect("/rooms/dining/")
    return redirect(f"/rooms/dining/")
def ping(request,num):
    timeout = timezone.now() - timedelta(seconds=30)

    # 1. 更新自己的心跳（如果房间还在）
    room = Room.objects.filter(code=num).first()
    if room:
        Player.objects.filter(room=room, user=request.user).update(last_ping=timezone.now())

    # 2. 全局清理：删掉所有超时玩家
    Player.objects.filter(last_ping__lt=timeout).delete()

    # 3. 全局清理：删掉所有空房间
    Room.objects.filter(players__isnull=True).delete()

    return JsonResponse({"ok": True})
