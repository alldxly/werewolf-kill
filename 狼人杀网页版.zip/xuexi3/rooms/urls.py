from django.urls import path
from . import views

urlpatterns = [
    # 大厅和固定路径
    path('dining/', views.dining_view, name="dining"),

    # ★ 把 start 放在前面，且路径明确


    # 房间相关
    path('<str:num>/', views.rooms_view, name="rooms"),
    path('leave/<str:num>/', views.leave_room, name="leave_room"),
    path('ping/<str:num>/', views.ping, name="ping"),

    # 如果你真的需要一个短路径直接访问房间（比如 /1234/），放在最后
]