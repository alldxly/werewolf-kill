from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login

roomcodelist = []



def register_view(request):
    if request.method == "POST":
        u = request.POST.get("username")
        p = request.POST.get("password")
        if User.objects.filter(username=u).exists():
            return render(request, "accounts/register.html", {"error": "用户名已存在"})
        User.objects.create_user(username=u, password=p)
        return redirect("/accounts/login/")
    return render(request, "accounts/register.html")

def login_view(request):
    if request.method == "POST":
        u = request.POST.get("username")
        p = request.POST.get("password")
        user = authenticate(request, username=u, password=p)
        if user:
            login(request, user)
            return redirect("/rooms/dining/")#此处修改登录后的界面
        return render(request, "accounts/login.html", {"error": "用户名或密码错误"})
    return render(request, "accounts/login.html")




