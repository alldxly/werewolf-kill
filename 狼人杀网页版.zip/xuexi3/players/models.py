from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Player(models.Model):
    room = models.ForeignKey("rooms.Room", on_delete=models.CASCADE, related_name="players")
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    joined_at = models.DateTimeField(auto_now_add=True)
    number = models.IntegerField(default=0)
    host=models.BooleanField(default=False)
    alive = models.BooleanField(default=True)
    role = models.CharField(max_length=20, default="")
    last_ping = models.DateTimeField(default=timezone.now)
    exe=models.CharField(max_length=200,default="")
    pingexe=models.BooleanField(default=False)
    sheriff=models.BooleanField(default=False)
    jing=models.CharField(max_length=200,default="")
    pingsheriff=models.BooleanField(default=False)
    sheriffjoin=models.BooleanField(default=False)
    werewolf=models.BooleanField(default=False)
    werewolftarget=models.CharField(default='')
    def __str__(self):
        return f"{self.user.username} in {self.room.code}"