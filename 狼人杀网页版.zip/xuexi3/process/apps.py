import os
import threading
import time
from django.apps import AppConfig


class ProcessConfig(AppConfig):
    name = 'process'

    def ready(self):
        # 只在 runserver 主进程起线程
        if os.environ.get("RUN_MAIN") != "true":
            return

        def loop():
            while True:
                time.sleep(1)
                try:
                    from process.views import auto_resolve_all
                    auto_resolve_all()
                except Exception as e:
                    print("[auto_resolve] error:", e)

        threading.Thread(target=loop, daemon=True).start()