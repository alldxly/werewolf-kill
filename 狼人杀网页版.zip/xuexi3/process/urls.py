from django.urls import path
from . import views


urlpatterns = [
    path('card/<str:num>/', views.card, name='card'),
    path('shuffle/<str:num>/', views.shuffle, name='shuffle'),
    path('gamenight/<str:num>/', views.gamenight, name='gamenight'),
    path('<str:num>/gamenighting/',views.gamenighting,name='gamenighting'),
    path('werewolf/<str:num>/', views.gamewerewolf, name='werewolf'),
    path('yu/<str:num>/', views.gameyu, name='yu'),
    path('shou/<str:num>/', views.gameshou, name='shou'),
    path('nv1/<str:num>/', views.gamenv1, name='nv1'),
    path('nv2/<str:num>/', views.gamenv2, name='nv2'),
    path('gameing/<str:num>/', views.gameing, name='gameing'),
    path('gameday/<str:num>/', views.gameday, name='gameday'),
    path('gameexe/<str:num>/', views.gameexe, name='gameexe'),
    path('gameexed/<str:num>/', views.gameexed, name='gameexed'),
    path('<str:num>/status/', views.status, name='status'),
    path('<str:num>/status_phase/', views.status_phase, name='status_phase'),   # ★ 新增
    path('start/<str:num>/', views.start, name='start'),
    path('<str:num>/start2/', views.start2, name='start2'),
    path('lie/<str:num>/', views.gamelieing, name='lie'),
    path('gamelie/<str:num>/',views.gamelie, name='gamelie'),
    path('langq/<str:num>/', views.gamelangqing, name='langq'),
    path('gamelangq/<str:num>/', views.gamelangq, name='gamelangq'),
    path('gamelied/<str:num>/', views.gamelied, name='gamelied'),
    path('gamelangqd/<str:num>/', views.gamelangqd, name='gamelangqd'),
    path('sheriff/<str:num>/', views.sheriff, name='sheriff'),
    path('sheriffed/<str:num>/', views.sheriffed, name='sheriffed'),
    path('sheriffing/<str:num>/', views.sheriffing, name='sheriffing'),
    path('sheriffjoin/<str:num>/', views.sheriffjoin, name='sheriffjoin'),
    path('sheriffjoining/<str:num>/', views.sheriffjoining, name='sheriffjoining'),
    path('sheriffshift/<str:num>/', views.sheriffshift, name='sheriffshift'),
    path('sheriffshifting/<str:num>/', views.sheriffshifting, name='sheriffshifting'),
    path('sheriffshifted/<str:num>/', views.sheriffshifted, name='sheriffshifted'),
    path('result/<str:num>/',views.result,name='result'),
]