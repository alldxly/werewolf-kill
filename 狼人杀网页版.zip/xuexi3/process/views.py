from django.shortcuts import render, redirect
from players.models import Player
from rooms.models import Room
from django.utils import timezone
from process.models import GameState
import json
from collections import Counter
from functools import wraps

# ============ 阶段路由表 ============
phasedict = {
    'waiting':'card',
    'shuffle': 'shuffle',
    'night': 'gamenight',
    'day': 'gameing',
    'vote1': 'gameday',
    'vote2': 'gameday',
    'exed': 'gameexed',
    'lie':'gamelie',
    'lied':'gamelied',
    'langq':'gamelangq',
    'langqd':'gamelangqd',
    'sheriff1':'sheriff',
    'sheriff2':'sheriff',
    'sheriffed':'sheriffed',
    'sheriffing':'sheriffing',
    'sheriffjoin':'sheriffjoin',
    'sheriffshift':'sheriffshift',
    'sheriffshifted':'sheriffshifted',
    'result':'result',
}

# ============ 游戏流程视图 ============
def checkday(allowed_phases, target_field):
    def day(view_func):
        @wraps(view_func)
        def _wrapped_view(request, num, *args, **kwargs):
            if request.method != "POST":
                return JsonResponse({"error": "只接受 POST"})
            room = Room.objects.filter(code=num).first()
            state = GameState.objects.filter(room=room).first()
            me = Player.objects.filter(room=room, user=request.user).first()
            if not room or not state or not me:
                return JsonResponse({"error": "数据异常"})
            # ★ 1. 检查是不是对应的阶段
            if state.phase not in allowed_phases:
                return JsonResponse({"error": "不在当前操作时间"})
            if state.phase == 'sheriffshift':
                if str(me.number) != str(state.oldsheriff) or me.alive:
                    return JsonResponse({'error': "你不是死亡警长，无法移交"})
                data = json.loads(request.body)
                target = data.get("target")
                newsheriff = Player.objects.filter(room=room, user__username=target).first()
                if not newsheriff or not newsheriff.alive:
                    return JsonResponse({"error": "只能移交给存活玩家"})
                newsheriff.sheriff = True
                newsheriff.save()
                state.phase_start = timezone.now()
                state.save()
                return JsonResponse({"ok": True, "msg": f"移交给 {target}"})
            # ★ 2. 检查平票限制（警长和处决的平票字段不一样）
            else:
                ping_field = 'pingsheriff' if target_field == 'jing' else 'pingexe'
                if getattr(me, ping_field):
                    return JsonResponse({"error": "平票玩家禁止投票"})

                if not me.alive:
                    return JsonResponse({"error": "你已死亡"})

                data = json.loads(request.body)
                target = data.get("target")

                # ★ 3. 第二轮投票，只能投平票玩家
                if state.phase in ('sheriff2', 'vote2'):
                    target_player = Player.objects.filter(room=room, user__username=target).first()
                    if not target_player or not getattr(target_player, ping_field):
                        return JsonResponse({"error": "只能投平票玩家"})
                if  me.sheriffjoin and me.pingexe:
                    return JsonResponse({'error':'禁止投票'})
                # ★ 4. 核心：动态给对应的字段赋值！
                setattr(me, target_field, target)
                me.save()
                return JsonResponse({"ok": True, "msg": f"投票给 {target}"})
        return _wrapped_view
    return day
def checknight(allowed_phases):
    def night(view_func):
        @wraps(view_func)
        def _wrapped_view(request, num, *args, **kwargs):
            if request.method != "POST":
                return JsonResponse({"error": "只接受 POST"})

            room = Room.objects.filter(code=num).first()
            state = GameState.objects.filter(room=room).first()
            me = Player.objects.filter(room=room, user=request.user).first()

            if not room or not state or not me:
                return JsonResponse({"error": "数据异常"})

            # ★ 1. 检查是不是对应的阶段
            if state.phase not in allowed_phases:
                return JsonResponse({"error": "不在当前操作时间"})
            if not me.alive:
                return JsonResponse({"error": "你已死亡"})
            return view_func(request,num,state,me,*args, **kwargs)
        return _wrapped_view
    return night

def require_room(view_func):
    @wraps(view_func)
    def _wrapped_view(request, num, *args, **kwargs):
        room = Room.objects.filter(code=num).first()
        if not room:
            if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.path.endswith('ing/'):
                return JsonResponse({"error": "房间不存在"})
            return redirect("/rooms/dining/")
        state = GameState.objects.filter(room=room).first()
        if not state:
            if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.path.endswith('ing/'):
                return JsonResponse({"error": "状态不存在"})
            return redirect("/rooms/dining/")
        me = Player.objects.filter(room=room, user=request.user).first()
        if not me:
            if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.path.endswith('ing/'):
                return JsonResponse({"error": "你不在房间"})
            return redirect("/rooms/dining/")
        # 把查好的变量直接塞给视图函数，视图函数不需要再自己查了！
        return view_func(request, num, state, me, *args, **kwargs)
    return _wrapped_view

def renewstate(state,now):
    state.phase_start=now
    state.save()
# ============ 后台线程：阶段推进 & 结算 ============
def auto_resolve_all():
    """后台线程每 1 秒跑一次，负责切阶段、结算"""
    now = timezone.now()
    # shuffle 显示 5 秒 → night
    for state in GameState.objects.filter(phase="shuffle"):
        elapsed = (now - state.phase_start).total_seconds()
        if elapsed >= 5:
            state.phase = "night"
            renewstate(state,now)
    # 1. 夜晚超时 → day
    for state in GameState.objects.filter(phase="night"):
        elapsed = (now - state.phase_start).total_seconds()
        if elapsed >= state.duration:
            state.figured=False
            if state.day==1:
                state.phase='sheriffjoin'
                renewstate(state,now)
            else:
                resolve_night(state)
                state.phase = "day"
                renewstate(state,now)
    for state in GameState.objects.filter(phase='sheriffshift'):
        elapsed = (now - state.phase_start).total_seconds()
        if elapsed>=state.durationsheriffshift:
            state.phase='sheriffshifted'
            renewstate(state,now)
    for state in GameState.objects.filter(phase='sheriffshifted'):
        elapsed = (now - state.phase_start).total_seconds()
        if elapsed >= 5:
            state.sheriffshift=False
            room = state.room
            if state.sheriffshiftnow=='day':
                state.phase='vote1'
                state.phase_start = now
                state.oldsheriff = 0
                state.sheriffshiftnow = ''
            else :
                gameclear(room,now)
                state.phase = 'night'
                state.phase_start = now
                if not state.dayadd:
                    state.day += 1
                    state.dayadd = True
                state.night_started = False
                state.toupiaodict = {}
                # ★ 关键修复：在这里直接清空 deadlist 和夜晚数据
                state.deadlist = ''
                state.werewolf = ''
                state.last_shou = state.shou if state.shou != '' else ''
                state.shou = ''
                state.yu = ''
                state.nv1 = ''
                state.nv2 = ''
                state.lieing = False
                state.lie = ''
                state.langqing = False
                state.langq = ''
                state.oldsheriff = 0
                state.sheriffshiftnow = ''
            state.exed_done=False
            state.save()
    for state in GameState.objects.filter(phase="sheriffjoin"):
        elapsed = (now - state.phase_start).total_seconds()
        if elapsed >= 15:
            if Player.objects.filter(room=state.room, sheriffjoin=True).exists():
                state.phase='sheriff1'
                renewstate(state,now)
            else:
                state.phase='sheriffed'
                renewstate(state,now)
    for state in GameState.objects.filter(phase__in=["sheriff1",'sheriff2']):
        elapsed=(now - state.phase_start).total_seconds()
        if elapsed>=state.durationsheriff:
            state.phase='sheriffed'
            renewstate(state,now)
    for state in GameState.objects.filter(phase='sheriffed'):
        if not state.sheriff_done:
            resolve_sheriff(state)
            state.sheriff_done = True
            renewstate(state, now)
            continue
        elapsed=(now - state.phase_start).total_seconds()
        if elapsed>=5:
            room = state.room
            if  state.last_sheriff_state:
                state.phase = 'sheriff2'
                state.pingsheriffround = 2
                state.phase_start = now
                state.toupiaodict = {}
                state.save()
                Player.objects.filter(room=room).update(jing="")  # 清空投票，准备重投
                Player.objects.filter(room=room, pingsheriff=False).update(sheriffjoin=False)
            else:
                state.phase = 'day'
                state.phase_start = now
                resolve_night(state)
                state.toupiaodict = {}#一轮投票正常白天
                Player.objects.filter(room=room).update(jing="")
            state.sheriff_done = False
            state.save()
    # day 显示 5 秒 → vote1
    for state in GameState.objects.filter(phase="day"):
        elapsed = (now - state.phase_start).total_seconds()
        state.werewolfd=False
        state.werewolfdict={}
        if elapsed>=5:
            room = state.room
            roles = list(Player.objects.filter(room=room, alive=True).values_list('role', flat=True))
            if '狼' not in roles and '狼王' not in roles and '民' in roles and (
                    '预' in roles or '女' in roles or '守' in roles or '猎' in roles):
                state.phase = 'result'
                state.winner = 'nice'
                state.started=False
                state.started2=False
                state.save()
            elif '民' not in roles or '预' not in roles and '女' not in roles and '猎' not in roles and '守' not in roles:
                state.phase = 'result'
                state.winner = 'werewolf'
                state.started=False
                state.started2=False
                state.save()
            elif state.lieing :
                if state.lieing and state.sheriffshift:
                    state.sheriffshiftnow='day'
                state.phase='lie'
                renewstate(state,now)
            elif state.sheriffshift:
                state.phase='sheriffshift'
                renewstate(state,now)
            else:
                state.phase = "vote1"
                renewstate(state,now)
    for state in GameState.objects.filter(phase="lie"):
        elasped = (now - state.phase_start).total_seconds()
        if elasped >= state.durationlie:
            state.phase='lied'
            state.lieing=False
            renewstate(state,now)
    for state in GameState.objects.filter(phase="lied"):
        elapsed=(now - state.phase_start).total_seconds()
        if elapsed >= 5:
            if state.langqing:
                state.phase='langq'
                renewstate(state,now)
            elif state.sheriffshift:
                state.phase = 'sheriffshift'
                renewstate(state,now)
            else:
                state.phase='vote1'
                renewstate(state,now)
    for state in GameState.objects.filter(phase="langq"):
        elapsed=(now - state.phase_start).total_seconds()
        if elapsed >= state.durationlangq:
            state.phase='langqd'
            state.langqing=False
            renewstate(state,now)
    for state in GameState.objects.filter(phase="langqd"):
        elapsed=(now - state.phase_start).total_seconds()
        if elapsed>=5:
            if state.lieing:
                state.phase='lie'
                renewstate(state,now)
            elif state.sheriffshift:
                state.phase = 'sheriffshift'
                renewstate(state,now)
            else:
                state.phase = 'vote1'
                renewstate(state,now)
    # 2. 投票超时 → exed
    for state in GameState.objects.filter(phase__in=["vote1", "vote2"]):
        elapsed = (now - state.phase_start).total_seconds()
        if elapsed >= state.duration2:
            state.phase = "exed"
            state.exed_done = False  # ★ 进入 exed，重置锁
            renewstate(state,now)
    # 3. exed → 结算（只算一次），5 秒后切 phase
    for state in GameState.objects.filter(phase="exed"):
        if not state.exed_done:
            # 第一次进 exed：算票，存结果
            resolve_vote(state)
            state.exed_done = True
            renewstate(state,now)
            continue
        # 已经算过，只看 5 秒
        elapsed = (now - state.phase_start).total_seconds()
        if elapsed >= 5:
            room = state.room
            roles = list(Player.objects.filter(room=room, alive=True).values_list('role', flat=True))
            if '狼' not in roles and '狼王' not in roles and '民' in roles and (
                    '预' in roles or '女' in roles or '守' in roles or '猎' in roles):
                state.phase = 'result'
                state.winner = 'nice'
                state.save()
            elif '民' not in roles or '预' not in roles and '女' not in roles and '猎' not in roles and '守' not in roles:
                state.phase = 'result'
                state.winner = 'werewolf'
                state.save()
            elif state.lieing:
                if state.sheriffshift:
                    state.sheriffshiftnow='night'
                state.phase='lie'
                renewstate(state,now)
            elif state.langqing:
                if state.sheriffshift:
                    state.sheriffshiftnow='night'
                state.phase='langq'
                renewstate(state,now)
            elif state.sheriffshift:
                state.phase='sheriffshift'
                renewstate(state,now)
            else:
                room = state.room
                if state.last_exe_state:
                    # 平票 → 第二轮投票
                    state.phase = 'vote2'
                    state.pingexeround = 2
                    state.toupiaodict = {}
                    renewstate(state,now)
                    Player.objects.filter(room=room).update(exe="")  # 清空投票，准备重投
                else:
                    # 出人 / 无人出局 → 下一晚
                    gameclear(room,now)
                    state.phase = 'night'
                    state.phase_start = now
                    if not state.dayadd:
                        state.day += 1
                        state.dayadd = True
                    state.night_started = False
                    state.toupiaodict = {}
                    # ★ 关键修复：在这里直接清空 deadlist 和夜晚数据
                    state.deadlist = ''
                    state.werewolf = ''
                    state.last_shou = state.shou if state.shou != '' else ''
                    state.shou = ''
                    state.yu = ''
                    state.nv1 = ''
                    state.nv2 = ''
                    state.lieing = False
                    state.lie = ''
                    state.langqing = False
                    state.langq = ''
                    state.oldsheriff = 0
                    state.sheriffshiftnow = ''
                state.exed_done = False
                state.save()
    for state in GameState.objects.filter(phase='result'):
        elapsed = (now - state.phase_start).total_seconds()
        if elapsed >= 15:
            room = state.room
            room.delete() # 直接抹除房间、玩家、状态
            continue

def resolve_night(state):
    deadlist = []
    if state.werewolf:
        if state.nv1 == state.werewolf and state.shou != state.werewolf or state.nv1 != state.werewolf and state.shou == state.werewolf:
            pass
        else:
            player = Player.objects.filter(room=state.room, user__username=state.werewolf).first()
            if player:
                deadlist.append(player.number)
                player.alive = False
                player.save()
    if state.nv2:
        player2 = Player.objects.filter(room=state.room, user__username=state.nv2).first()
        if player2.number not in deadlist:
            deadlist.append(player2.number)
        player2.alive = False
        player2.save()
    player3=Player.objects.filter(room=state.room, user__username=state.werewolf).first()
    if player3:
        if player3.number in deadlist and player3.user.username!=state.nv2 and player3.role=='猎':
            state.lieing=True
            state.save()
    playersheriff=Player.objects.filter(room=state.room, sheriff=True,alive=False).first()
    if playersheriff:
        for a in deadlist:
            if a==playersheriff.number:
                playersheriff.sheriff=False
                state.sheriffshift=True
                state.oldsheriff=playersheriff.number
                state.save()
                playersheriff.save()
    state.deadlist = ",".join(str(n) for n in deadlist)
    state.save()

def resolve_sheriff(state):
    room = state.room
    players = Player.objects.filter(room=room, alive=True)
    votes = [p.jing for p in players if p.jing]
    count = Counter(votes)
    username_to_number = {p.user.username: p.number for p in Player.objects.filter(room=room)}
    toupiaodict = {}
    # 没人投票
    if not count:
        state.last_sheriff = ""
        state.last_sheriff_state = False
        state.pingsheriff = False
        state.pingsheriffround = 1
        state.save()
        return
    for p in players:
        if p.jing:
            # 2. 拿到投给目标的号码（如果目标不存在，防崩处理）
            target_number = username_to_number.get(p.jing)

            if target_number:
                if target_number not in toupiaodict:
                    toupiaodict[target_number] = []
                toupiaodict[target_number].append(p.number)
    state.toupiaodict = toupiaodict
    print(toupiaodict)
    state.save()
    max_count = max(count.values())
    most_voted_list = [name for name, c in count.items() if c == max_count]
    # 平票
    if len(most_voted_list) > 1:
        Player.objects.filter(room=room, user__username__in=most_voted_list).update(pingsheriff=True)
        sheriff_numbers = list(
            Player.objects.filter(room=room, user__username__in=most_voted_list)
            .values_list("number", flat=True)
        )
        state.last_sheriff = ",".join(str(n) for n in sheriff_numbers)
        if state.pingsheriffround == 1:
            # 第一次平票
            state.last_sheriff_state = True
            state.pingsheriff = True
            state.save()
            return
        else:
            # 第二次平票
            Player.objects.filter(room=room).exclude(user__username__in=most_voted_list).update(sheriffjoin=False)
            state.last_sheriff_state = False
            state.pingsheriff = False
            state.pingsheriffround = 1
            state.save()
            return
    # 唯一最多票 → 当选
    target = most_voted_list[0]
    sheriffed = Player.objects.filter(room=room, user__username=target).first()
    if sheriffed:
        sheriffed.sheriff=True
        sheriffed.save()
    Player.objects.filter(room=room).update(sheriffjoin=False)
    state.last_sheriff = str(sheriffed.number) if sheriffed else ""
    state.last_sheriff_state = False
    state.pingsheriff = False
    state.pingsheriffround = 1
    state.save()

def resolve_vote(state):
    """只算票、存结果，不改 phase、不 gameclear、不 day += 1"""
    room = state.room
    players = Player.objects.filter(room=room, alive=True)
    votes = [p.exe for p in players if p.exe]
    count = Counter(votes)
    username_to_number = {p.user.username: p.number for p in Player.objects.filter(room=room)}
    toupiaodict = {}
    # 没人投票
    if not count:
        state.last_exe = ""
        state.last_exe_state = False
        state.pingexe = False
        state.pingexeround = 1
        state.save()
        Player.objects.filter(room=room).update(pingexe=False, exe='')
        return
    for p in players:
        if p.exe:
            # 2. 拿到投给目标的号码（如果目标不存在，防崩处理）
            target_number = username_to_number.get(p.exe)

            if target_number:
                if target_number not in toupiaodict:
                    toupiaodict[target_number] = []
                toupiaodict[target_number].append(p.number)
    state.toupiaodict = toupiaodict
    print(toupiaodict)
    state.save()
    max_count = max(count.values())
    most_voted_list = [name for name, c in count.items() if c == max_count]
    # 平票
    if len(most_voted_list) > 1:
        sheriff = Player.objects.filter(room=room, sheriff=True).first()
        # ★ 安全防范：有警长，且警长投了票，且投的人在平票名单里
        if sheriff and sheriff.exe and sheriff.exe in most_voted_list:
            exed = Player.objects.filter(room=room, user__username=sheriff.exe).first()
            if exed:
                exed.alive = False
                exed.save()
                if exed.role == '猎':
                    state.lieing = True
                if exed.role == '狼王':
                    state.langqing = True
                if exed.sheriff:
                    state.sheriffshift = True
                    exed.sheriff = False
                    state.oldsheriff = exed.number
                    exed.save()
            state.last_exe = str(exed.number) if exed else ""
            state.last_exe_state = False
            state.pingexe = False
            state.pingexeround = 1
            Player.objects.filter(room=room).update(pingexe=False, exe='')
            state.save()
            return  # ★ 核心修复：绝杀结束，直接返回，禁止穿透！
        else:
            # 正常平票逻辑（进 PK 台）
            Player.objects.filter(room=room, user__username__in=most_voted_list).update(pingexe=True)
            Player.objects.filter(room=room).exclude(user__username__in=most_voted_list).update(pingexe=False)
            exe_numbers = list(
                Player.objects.filter(room=room, user__username__in=most_voted_list)
                .values_list("number", flat=True)
            )
            state.last_exe = ",".join(str(n) for n in exe_numbers)
            if state.pingexeround == 1:
                state.last_exe_state = True
                state.pingexe = True
                state.save()
                return
            else:
                state.last_exe_state = False
                state.pingexe = False
                state.pingexeround = 1
                state.save()
                return
    # 唯一最多票 → 出局 (这里是平票没发生，或者平票逻辑已经 return 走完了)
    target = most_voted_list[0]
    exed = Player.objects.filter(room=room, user__username=target).first()
    if exed:
        exed.alive = False
        exed.save()
        if exed.role == '猎':
            state.lieing = True
        if exed.role == '狼王':
            state.langqing = True
        if exed.sheriff:
            state.sheriffshift = True
            exed.sheriff = False
            state.oldsheriff = exed.number
            exed.save()
    state.last_exe = str(exed.number) if exed else ""
    state.last_exe_state = False
    state.pingexe = False
    state.pingexeround = 1
    Player.objects.filter(room=room).update(pingexe=False, exe='')
    state.save()

# ============ 辅助函数 ============
def gameclear(room,now):
    state = GameState.objects.filter(room=room).first()
    if not state:
        return
    Player.objects.filter(room=room).update(pingexe=False, exe='')
# ============ 游戏开始前的接口 ============
import random
from django.http import JsonResponse
def status(request, num):
    room = Room.objects.filter(code=num).first()
    if not room:
        return JsonResponse({"started": False})
    state = GameState.objects.filter(room=room).first()
    started = state and state.started if state else False
    # ★ 核心：每次轮询时，检查房间里有没有房主
    host_exists = Player.objects.filter(room=room, host=True).exists()
    hostshift = False
    if not host_exists:
        # 没房主，随机选一个
        p_numbers = list(Player.objects.filter(room=room).values_list('number', flat=True))
        if p_numbers:
            random.shuffle(p_numbers)
            newhost = Player.objects.filter(room=room, number=p_numbers[0]).first()
            if newhost:
                newhost.host = True
                newhost.save()
                hostshift = True  # 告诉前端：房主换了，赶紧刷新！
    players = list(room.players.all().order_by("number").values("number", "user__username", "host"))
    return JsonResponse({
        "started": started,
        "count": len(players),
        "players": players,
        "hostshift": hostshift,# 把这个标志传给前端
    })

@require_room
def status_phase(request, num, state, me):
    """查询当前 phase，前端轮询用"""
    return JsonResponse({
        "phase": state.phase,
        "url": f"/process/{phasedict[state.phase]}/{num}/",
    })

def start(request, num):
    room = Room.objects.filter(code=num).first()
    if not room:
        return redirect("/rooms/dining/")
    me = Player.objects.filter(room=room, user=request.user).first()
    if not me:
        return redirect("/rooms/dining/")
    state = GameState.objects.filter(room=room).first()
    if not state:
        state = GameState.objects.create(room=room)
    state.started = True
    state.save()
    return redirect(f"/process/card/{num}/")

@require_room
def start2(request, num, state, me):
    chosen = state.started2
    return JsonResponse({"chosen": chosen})
# ============ 游戏流程视图 ============
@require_room
def card(request, num,state,me):
    if request.method == 'POST':
        idtype = request.POST.get('idtype')
        if idtype == '狼枪守卫':
            state.phase='shuffle'
            state.started2 = True
            renewstate(state, timezone.now())
            return redirect(f'/process/shuffle/{num}/')
        else:
            return render(request, "card.html", {
                'roomcode': num, 'error': '板子不存在', 'me': me,
            })
    return render(request, 'card.html', {'roomcode': num, 'me': me})

@require_room
def shuffle(request, num,state,me):
    # 游戏已开始，跳当前阶段
    if state.phase != 'shuffle':
        return redirect(f'/process/{phasedict[state.phase]}/{num}/')
    else:
        room=state.room
        players = list(room.players.all().order_by("number"))
        # 发牌
        if not room.players.exclude(role="").exists():
            roles = ['预','女','猎','守','狼','狼','狼','狼王','民','民','民','民']
            random.shuffle(roles)
            for player, role in zip(players, roles):
                player.role = role
                player.save()
            if state:
                state.night_started = False
                state.save()
        me.refresh_from_db()
        print("shuffle me.role =", me.role)
        if me.role in ['狼','狼王']:
            me.werewolf=True
            me.save()
        return render(request, "shuffle.html", {
            "roomcode": num,
            "number": me.number,
            "role": me.role,
        })

@require_room
def gamenight(request, num,state,me):
    room=state.room
    # ★ 只读 phase，不对就跳
    if state.phase != "night":
        return redirect(f"/process/{phasedict[state.phase]}/{num}/")
    # 第一次进入夜晚时初始化
    if not state.night_started:
        GameState.objects.filter(room=room).update(
            phase="night",
            phase_start=timezone.now(),
            duration=60,
            night_started=True,
            last_exe='',
            last_exe_state=False,
            pingexe=False,
            pingexeround=1,
            yud=False,
            nv1='',
            dayadd=False,
        )
    players = list(room.players.all().order_by("number"))
    print("gamenight me.role =", me.role)
    elapsed = (timezone.now() - state.phase_start).total_seconds()
    game_data = {
        "phase_start": state.phase_start.timestamp(),
        "duration": state.duration,
    }
    action = None
    if me.role == "女":
        if 30 <= elapsed < 45:
            action = "save"
        elif 45 <= elapsed < 60:
            action = "poison"
    elif me.role in ("狼", "狼王"):
        if 0 <= elapsed < 30:
            action = "kill"
    elif me.role in ("预", "守"):
        action = me.role
    return render(request, "gamenight.html", {
        "roomcode": num,
        "role": me.role,
        'alive': me.alive,
        'me':me,
        "number": me.number,
        "game_data": game_data,
        'night': state.day,
        'players': players,
        'action': action,
        'state':state,
        'nv1d': state.nv1d,
    })

@require_room
def gamenighting(request,num,state,me):
    elapsed = (timezone.now() - state.phase_start).total_seconds()
    if elapsed>=30:
        if elapsed >= 30 and not state.werewolfd:
            room = state.room
            # 提取所有狼人的投票，并过滤掉空票
            targetlist = list(Player.objects.filter(room=room, werewolf=True).values_list('werewolftarget', flat=True))
            targetlist = [t for t in targetlist if t]
            finaltarget = Counter(targetlist)
            if not finaltarget:
                # 没人投票，刀空
                state.werewolf = ''
            else:
                max_count = max(finaltarget.values())
                most_voted_list = [name for name, c in finaltarget.items() if c == max_count]
                random.shuffle(most_voted_list)
                state.werewolf = most_voted_list[0]
                print(state.werewolf)
                # --- 开始组装展示用的投票字典 (werewolfdict) ---
                werewolfdict = {}
                players = Player.objects.filter(room=room, alive=True)
                # 使用字典映射，避免在循环里疯狂查数据库
                players_dict = {p.user.username: p for p in players}
                for p in players:
                    target_username = p.werewolftarget
                    if target_username:
                        b = players_dict.get(target_username)
                        if b:  # 防空：确保目标依然存活且存在
                            c = b.number
                            if c not in werewolfdict:
                                werewolfdict[c] = []
                            werewolfdict[c].append(p.number)
                state.werewolfdict = werewolfdict
            # 统一清空当前房间的投票（防止下一轮数据错乱）
            Player.objects.filter(room=room).update(werewolftarget='')
            # 上锁，防止后台线程下一秒再次重复结算
            state.werewolfd = True
            state.save()
    return JsonResponse({ "state": {"werewolfd": state.werewolfd,"werewolf": state.werewolf,"nv1d": state.nv1d},'roomcode':num,  "me": {
            "role": me.role,
            "alive": me.alive
        }})

@require_room
def gameing(request, num,state,me):
    room=state.room
    # ★ 只读 phase
    if state.phase != "day":
        return redirect(f"/process/{phasedict[state.phase]}/{num}/")
    deadlist = state.deadlist.split(",") if state.deadlist else []
    random.shuffle(deadlist)
    print("gameing 打印 deadlist:", deadlist)
    players = list(room.players.all().order_by("number"))
    me=Player.objects.filter(room=room, user=request.user).first()
    return render(request, "gameing.html", {
        "deadlist": deadlist,
        "roomcode": num,
        'players': players,
        'role':me.role,
        'lieing':state.lieing,
    })

@require_room
def gameday(request, num,state,me):
    room=state.room
    # ★ 只读 phase
    if state.phase not in ("vote1", "vote2"):
        return redirect(f"/process/{phasedict[state.phase]}/{num}/")
    players = Player.objects.filter(room=room)
    game_data = {
        "phase_start": state.phase_start.timestamp(),
        "duration2": state.duration2,
    }
    return render(request, "gameday.html", {
        'players': players,
        'game_data': game_data,
        "roomcode": num,
        "role": me.role,
        "number": me.number,
        'state': state,
        'me': me,
        'night': state.day,
    })

@checkday(allowed_phases=['vote1','vote2'], target_field='exe')
def gameexe(request, num):
    pass

@require_room
def gameexed(request, num,state,me):
    room=state.room
    players=list(room.players.all().order_by("number"))
    # ★ 只读结果，不结算
    return render(request, "gameexe.html", {
        "last_exe": state.last_exe.split(",") if state.last_exe else [],
        "state": state.last_exe_state,
        "roomcode": num,
        "toupiaodict": state.toupiaodict,
        'players':players,
        'role':me.role,
        'lieing':state.lieing,
        'langqing':state.langqing,
    })

# ============ 夜晚操作接口 ============
@checknight(allowed_phases=['night'])
def gamewerewolf(request, num,state,me):
    if me.role not in ("狼", "狼王"):
        return JsonResponse({"error": "你不是狼人"})
    elapsed = (timezone.now() - state.phase_start).total_seconds()
    if not (0 <= elapsed < 30):
        return JsonResponse({"error": "不在狼人行动时间"})
    data = json.loads(request.body)
    target = data.get("target")
    me.werewolftarget=target
    me.save()
    return JsonResponse({"ok": True, "msg": f"刀了 {target}"})

@checknight(allowed_phases=['night'])
def gameyu(request, num,state,me):
    room=state.room
    elapsed = (timezone.now() - state.phase_start).total_seconds()
    if not (0 <= elapsed < 60):
        return JsonResponse({"error": "不在预言家行动时间"})
    if state.yud == False:
        data = json.loads(request.body)
        target = data.get("target")
        yutarget = Player.objects.filter(room=room, user__username=target).first()
        if not yutarget:
            return JsonResponse({"error": "目标不存在"})
        state.yu = target
        state.yud = True
        state.save()
        if yutarget.werewolf:
            return JsonResponse({"ok": True, "msg": f"查验 {target} 为狼人"})
        else:
            return JsonResponse({"ok": True, "msg": f"查验 {target} 为好人"})
    else:
        return JsonResponse({'error': '已查验过'})

@checknight(allowed_phases=['night'])
def gameshou(request, num,state,me):
    if me.role != '守':
        return JsonResponse({"error": "你不是守卫"})
    print(state.shou)
    elapsed = (timezone.now() - state.phase_start).total_seconds()
    if not (0 <= elapsed < 60):
        return JsonResponse({"error": "不在守卫行动时间"})
    data = json.loads(request.body)
    target = data.get("target")
    if target != state.last_shou:
        state.shou = target
        state.save()
        return JsonResponse({"ok": True, "msg": f"守护 {target}"})
    else:
        return JsonResponse({'ok': False, 'msg': '不能连守'})

@checknight(allowed_phases=['night'])
def gamenv1(request, num,state,me):
    if me.role != '女':
        return JsonResponse({"error": "你不是女巫"})
    elapsed = (timezone.now() - state.phase_start).total_seconds()
    if not (30 <= elapsed < 45):
        return JsonResponse({"error": "不在女巫救人行动时间"})
    if state.nv1d == False:
        werewolf = state.werewolf
        if werewolf:
            if me.role == '女' and werewolf==me.user.username:
                return JsonResponse({'msg': '女巫不能自救'})
            else:
                state.nv1 = werewolf
                state.nv1d = True
                state.save()
                return JsonResponse({"ok": True, "msg": f"救活 {werewolf}"})
        else:
            return JsonResponse({"error": "今晚没人被刀"})
    else:
        return JsonResponse({"error": "已救过人"})

@checknight(allowed_phases=['night'])
def gamenv2(request, num,state,me):
    if me.role != '女':
        return JsonResponse({"error": "你不是女巫"})
    elapsed = (timezone.now() - state.phase_start).total_seconds()
    if not (45 <= elapsed < 60):
        return JsonResponse({"error": "不在女巫毒人时间"})
    if state.nv1 == '':
        if state.nv2d == False:
            data = json.loads(request.body)
            target = data.get("target")
            state.nv2 = target
            state.nv2d = True
            state.save()
            return JsonResponse({"ok": True, "msg": f"毒杀 {target}"})
        else:
            return JsonResponse({"error": "已毒过人"})
    else:
        return JsonResponse({'ok': False, 'msg': '救人后当晚不能毒人'})

@require_room
def gamelie(request,num,state,me):
    room = state.room
    players = list(room.players.all().order_by("number"))
    return render(request,'gamelie.html',{'roomcode':num,'players':players,'state':state,'role':me.role})

def gamelieing(request, num):
    if request.method != "POST":
        return JsonResponse({'error': '只接受 POST'})
    room = Room.objects.filter(code=num).first()
    me = Player.objects.filter(room=room, user=request.user).first()
    if me.role != '猎':
        return JsonResponse({'error': "你不是猎人"})
    state = GameState.objects.filter(room=room).first()
    elapsed = (timezone.now() - state.phase_start).total_seconds()
    if not (0 <= elapsed < state.durationlie):
        return JsonResponse({'error': '猎人开枪超时'})
    data = json.loads(request.body)
    target = data.get("target")
    player = Player.objects.filter(room=room, user__username=target).first()
    if player:
        player.alive = False
        player.save()
        if player.role=='狼王':
            state.langqing=True
        if player.sheriff:
            state.sheriff=True
            player.sheriff=False
            state.oldsheriff = player.number
            player.save()
    state.lieing=False
    state.lie=target
    state.save()
    return JsonResponse({"ok": True, "msg": f"枪杀 {target}"})

@require_room
def gamelied(request,num,state,me):
    room=state.room
    player=Player.objects.filter(room=room, role='猎').first()
    number=player.number
    target=Player.objects.filter(room=room, user__username=state.lie).first()
    if target:
        targetnumber = target.number
    else:
        targetnumber = ''
    return render(request,'gamelied.html',{'lie':number,'target':targetnumber,'roomcode':num,})

@require_room
def gamelangq(request,num,state,me):
    room=state.room
    players = list(room.players.all().order_by("number"))
    return render(request, 'gamelangq.html', {'roomcode': num, 'players': players, 'state': state, 'role': me.role})

def gamelangqing(request,num):
    if request.method != "POST":
        return JsonResponse({'error': '只接受 POST'})
    room = Room.objects.filter(code=num).first()
    me = Player.objects.filter(room=room, user=request.user).first()
    if me.role != '狼王':
        return JsonResponse({'error': "你不是狼王"})
    state = GameState.objects.filter(room=room).first()
    elapsed = (timezone.now() - state.phase_start).total_seconds()
    if not (0 <= elapsed < state.durationlangq):
        return JsonResponse({'error': '狼王反击超时'})
    data = json.loads(request.body)
    target = data.get("target")
    player = Player.objects.filter(room=room, user__username=target).first()
    if player:
        player.alive = False
        player.save()
        if player.role=='猎':
            state.lieing=True
        if player.sheriff:
            state.sheriffshift=True
            state.oldsheriff = player.number
            player.sheriff=False
            player.save()
    state.langqing=False
    state.langq=target
    state.save()
    return JsonResponse({"ok": True, "msg": f"反杀 {target}"})

@require_room
def gamelangqd(request,num,state,me):
    room=state.room
    player = Player.objects.filter(room=room, role='狼王').first()
    number = player.number
    target = Player.objects.filter(room=room, user__username=state.langq).first()
    if target:
        targetnumber = target.number
    else:
        targetnumber=''
    return render(request, 'gamelangqd.html', {'langq': number, 'target': targetnumber, 'roomcode': num, })

@require_room
def sheriff(request,num,state,me):
    room=state.room
    # ★ 只读 phase
    if state.phase not in ("sheriff1", "sheriff2"):
        return redirect(f"/process/{phasedict[state.phase]}/{num}/")
    players = Player.objects.filter(room=room)
    game_data = {
        "phase_start": state.phase_start.timestamp(),
        "durationsheriff": state.durationsheriff,
    }
    return render(request, "sheriff.html", {
        'players': players,
        'game_data': game_data,
        "roomcode": num,
        "role": me.role,
        "number": me.number,
        'state': state,
        'me': me,
        'night': state.day,
    })

@require_room
def sheriffed(request,num,state,me):
    room = state.room
    players = list(room.players.all().order_by("number"))
    # ★ 只读结果，不结算
    return render(request, "sheriffed.html", {
        "last_sheriff": state.last_sheriff.split(",") if state.last_sheriff else [],
        "state": state.last_sheriff_state,
        "roomcode": num,
        "toupiaodict": state.toupiaodict,
        'players': players,
        'role': me.role,
    })

@checkday(allowed_phases=['sheriff1','sheriff2'], target_field='jing')
def sheriffing(request,num):
   pass

@require_room
def sheriffjoin(request,num,state,me):
    room=state.room
    # ★ 只读 phase
    if state.phase!='sheriffjoin':
        return redirect(f"/process/{phasedict[state.phase]}/{num}/")
    me = Player.objects.filter(room=room, user=request.user).first()
    return render(request,'sheriffjoin.html',{'roomcode':num,'role':me.role,'number':me.number})

def sheriffjoining(request,num):
    if request.method != "POST":
        return JsonResponse({"error": "只接受 POST"})
    room = Room.objects.filter(code=num).first()
    if not room:
        return JsonResponse({"error": "房间不存在"})
    state = GameState.objects.filter(room=room).first()
    me = Player.objects.filter(room=room, user=request.user).first()
    if me.sheriffjoin:
        return JsonResponse({'error':'已参加竞选'})
    if state.phase != 'sheriffjoin':
        return JsonResponse({"error": "不在参加时间"})
    me.sheriffjoin=True
    me.save()
    return JsonResponse({"ok": True,'msg':'参加竞选成功'})

@require_room
def sheriffshift(request,num,state,me):
    room=state.room
    # ★ 只读 phase
    if state.phase !='sheriffshift':
        return redirect(f"/process/{phasedict[state.phase]}/{num}/")
    players = Player.objects.filter(room=room)
    me = Player.objects.filter(room=room, user=request.user).first()
    game_data = {
        "phase_start": state.phase_start.timestamp(),
        "durationsheriffshift": state.durationsheriff,
    }
    return render(request, "sheriffshift.html", {
        'players': players,
        'game_data': game_data,
        "roomcode": num,
        "role": me.role,
        "number": me.number,
        'state': state,
        'me': me,
        'night': state.day,
    })

@checkday(allowed_phases=['sheriffshift'], target_field='')
def sheriffshifting(request, num):
    pass

@require_room
def sheriffshifted(request,num,state,me):
    room=state.room
    newsheriff = Player.objects.filter(room=room, sheriff=True,alive=True).first()
    if newsheriff:
        new = newsheriff.number
    else:
        new=''
    old = state.oldsheriff
    return render(request,'sheriffshifted.html',{'roomcode':num,'old':old,'new':new})

@require_room
def result(request,num,state,me):
    room=state.room
    players = list(room.players.all().order_by("number"))
    return render(request,'result.html',{'roomcode':num,'winner':state.winner,'players':players})