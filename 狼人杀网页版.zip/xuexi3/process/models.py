# process/models.py
from django.db import models
from django.utils import timezone


class GameState(models.Model):
    room = models.ForeignKey("rooms.Room", on_delete=models.CASCADE, related_name="game_states")

    # 阶段
    day = models.IntegerField(default=1)
    phase = models.CharField(max_length=20, default="waiting")
    phase_start = models.DateTimeField(default=timezone.now)
    duration = models.IntegerField(default=62)     # 夜晚时长
    duration2 = models.IntegerField(default=22)    # 投票时长

    # 夜晚操作
    werewolf = models.CharField(max_length=20, default="")
    werewolfd = models.BooleanField(default=False)
    werewolfdict = models.JSONField(default=dict)
    renew = models.BooleanField(default=False)  # 这是无用参数
    figured=models.BooleanField(default=False)
    yu = models.CharField(max_length=20, default='')
    nv1 = models.CharField(max_length=20, default='')
    nv2 = models.CharField(max_length=20, default='')
    shou = models.CharField(max_length=20, default='')
    nv1d = models.BooleanField(default=False)
    nv2d = models.BooleanField(default=False)
    yud = models.BooleanField(default=False)
    last_shou = models.CharField(max_length=20, default='')
    durationlangq=models.IntegerField(default=20)
    durationlie=models.IntegerField(default=20)
    lie=models.CharField(max_length=20,default='')
    lieing=models.BooleanField(default=False)
    lied=models.BooleanField(default=False)
    durationsheriff=models.IntegerField(default=20)
    durationsheriffshift=models.IntegerField(default=10)


    #投票(警徽)
    last_sheriff_state=models.BooleanField(default=False)#警徽平票判断
    sheriff_done=models.BooleanField(default=False)#警徽是否执行
    pingsheriffround=models.IntegerField(default=1)#警徽轮数
    pingsheriff=models.BooleanField(default=False)#本轮是否平票(警徽)
    last_sheriff=models.CharField(max_length=200, default="")#是否结算投票(警徽)
    sheriffshift=models.BooleanField(default=False)
    sheriffshiftnow=models.CharField(max_length=200, default="")
    oldsheriff=models.IntegerField(default=0)





    deadlist = models.CharField(max_length=200, default="")#死亡结果



    #投票情况
    last_exe = models.CharField(max_length=200, default="")
    last_exe_state = models.BooleanField(default=False)
    pingexe = models.BooleanField(default=False)          # 本轮是否平票
    pingexeround = models.IntegerField(default=1)         # 第几轮平票
    exed_done = models.BooleanField(default=False)        # 本 exed 是否已结算


    toupiaodict = models.JSONField(default=dict)          # 每轮投票显示

    langq= models.CharField(default=0)
    langqing = models.BooleanField(default=False)
    langqd=models.BooleanField(default=False)

    # 流程标志
    started = models.BooleanField(default=False)
    started2 = models.BooleanField(default=False)
    night_started = models.BooleanField(default=False)

    dayadd= models.BooleanField(default=False)#日期锁
    skill=models.BooleanField(default=False)#是否存在发动技能情况

    winner=models.CharField(default='')

    def __str__(self):
        return f"{self.room.code} - Day {self.day} - {self.phase}"